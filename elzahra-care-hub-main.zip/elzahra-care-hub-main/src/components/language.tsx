import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

type Language = "ar" | "fr";
type Dictionary = Record<string, { ar: string; fr: string }>;

const translations: Dictionary = {
  home: { ar: "الرئيسية", fr: "Accueil" },
  services: { ar: "خدماتنا", fr: "Nos services" },
  about: { ar: "عن العيادة", fr: "La clinique" },
  team: { ar: "الفريق الطبي", fr: "Équipe médicale" },
  patients: { ar: "معلومات المرضى", fr: "Infos patients" },
  contact: { ar: "اتصل بنا", fr: "Contact" },
  book: { ar: "احجز موعدًا", fr: "Demander un rendez-vous" },
  call: { ar: "اتصل", fr: "Appeler" },
  location: { ar: "الموقع", fr: "Itinéraire" },
};

type LanguageContextValue = {
  language: Language;
  dir: "rtl" | "ltr";
  setLanguage: (language: Language) => void;
  t: (key: keyof typeof translations) => string;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar");

  useEffect(() => {
    const saved = window.localStorage.getItem("elzahra-language");
    if (saved === "ar" || saved === "fr") setLanguage(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    window.localStorage.setItem("elzahra-language", language);
  }, [language]);

  const value = useMemo<LanguageContextValue>(() => ({
    language,
    dir: language === "ar" ? "rtl" : "ltr",
    setLanguage,
    t: (key) => translations[key][language],
  }), [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within LanguageProvider");
  return context;
}
