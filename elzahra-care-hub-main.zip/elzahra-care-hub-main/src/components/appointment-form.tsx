import { useState, type FormEvent } from "react";
import { CalendarCheck, CheckCircle2, Loader2, Phone } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/components/language";

const schema = z.object({
  full_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(8).max(30).regex(/^[+\d\s()-]+$/),
  email: z.union([z.literal(""), z.string().trim().email().max(255)]),
  consultation_type: z.string().trim().min(1).max(120),
  preferred_date: z.string().date(),
  preferred_time: z.string().trim().min(1).max(30),
  message: z.string().trim().max(1000),
  website: z.string().max(0),
});

export function AppointmentForm() {
  const { language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const ar = language === "ar";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError("");
    const form = new FormData(event.currentTarget);
    const values = Object.fromEntries(form.entries());
    const parsed = schema.safeParse(values);
    if (!parsed.success) { setError(ar ? "يرجى مراجعة الحقول وإدخال معلومات صحيحة." : "Veuillez vérifier les informations saisies."); return; }
    setLoading(true);
    const { website, email, ...payload } = parsed.data;
    if (website) { setLoading(false); return; }
    const { error: insertError } = await supabase.from("appointment_requests").insert({ ...payload, email: email || null, message: payload.message || null });
    setLoading(false);
    if (insertError) { setError(ar ? "تعذر إرسال الطلب الآن. يرجى الاتصال بالعيادة." : "Envoi impossible. Veuillez appeler la clinique."); return; }
    setSuccess(true); event.currentTarget.reset();
  }

  if (success) return <div className="rounded-lg border border-success/25 bg-success-soft p-7 text-center"><CheckCircle2 className="mx-auto mb-4 size-12 text-success" /><h3 className="font-display text-xl text-foreground">{ar ? "تم إرسال طلب موعدك" : "Votre demande a été envoyée"}</h3><p className="mx-auto mt-2 max-w-lg text-sm leading-7 text-muted-foreground">{ar ? "شكرًا لكم. ستتواصل العيادة معكم لتأكيد الموعد. هذا الطلب لا يمثل تأكيدًا نهائيًا." : "Merci. La clinique vous contactera pour confirmer. Cette demande ne constitue pas une confirmation définitive."}</p><Button className="mt-5" onClick={() => setSuccess(false)}>{ar ? "إرسال طلب آخر" : "Nouvelle demande"}</Button></div>;

  const labelClass = "mb-2 block text-sm font-semibold text-foreground";
  return <form onSubmit={submit} className="grid gap-5" noValidate>
    <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
    <div className="grid gap-5 sm:grid-cols-2"><label><span className={labelClass}>{ar ? "الاسم الكامل" : "Nom complet"} *</span><Input name="full_name" required maxLength={120} /></label><label><span className={labelClass}>{ar ? "رقم الهاتف" : "Téléphone"} *</span><Input name="phone" type="tel" inputMode="tel" required maxLength={30} /></label></div>
    <div className="grid gap-5 sm:grid-cols-2"><label><span className={labelClass}>{ar ? "البريد الإلكتروني — اختياري" : "E-mail — facultatif"}</span><Input name="email" type="email" maxLength={255} /></label><label><span className={labelClass}>{ar ? "نوع الاستشارة" : "Type de consultation"} *</span><select name="consultation_type" required defaultValue="" className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"><option value="" disabled>{ar ? "اختر نوع الاستشارة" : "Choisir"}</option><option>{ar ? "الأنف والجيوب الأنفية" : "Nez et sinus"}</option><option>{ar ? "الأذن والسمع" : "Oreille et audition"}</option><option>{ar ? "الحنجرة والصوت" : "Larynx et voix"}</option><option>{ar ? "فحص ORL" : "Examen ORL"}</option><option>{ar ? "طب الأطفال ORL" : "ORL pédiatrique"}</option></select></label></div>
    <div className="grid gap-5 sm:grid-cols-2"><label><span className={labelClass}>{ar ? "التاريخ المفضل" : "Date souhaitée"} *</span><Input name="preferred_date" type="date" required min={new Date().toISOString().split("T")[0]} /></label><label><span className={labelClass}>{ar ? "الوقت المفضل" : "Moment souhaité"} *</span><select name="preferred_time" required defaultValue="" className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"><option value="" disabled>{ar ? "اختر الوقت" : "Choisir"}</option><option>{ar ? "صباحًا" : "Matin"}</option><option>{ar ? "بعد الظهر" : "Après-midi"}</option></select></label></div>
    <label><span className={labelClass}>{ar ? "رسالة إضافية — دون معلومات طبية حساسة" : "Message — sans données médicales sensibles"}</span><Textarea name="message" rows={4} maxLength={1000} /></label>
    {error && <p role="alert" className="rounded-md bg-destructive-soft p-3 text-sm font-semibold text-destructive">{error}</p>}
    <div className="flex flex-col gap-3 sm:flex-row"><Button type="submit" size="lg" disabled={loading}>{loading ? <Loader2 className="animate-spin" /> : <CalendarCheck />}{ar ? "إرسال طلب الموعد" : "Envoyer la demande"}</Button><Button asChild variant="outline" size="lg"><a href="tel:+213697978015"><Phone />{ar ? "اتصل الآن: 0697 97 80 15" : "Appeler : 0697 97 80 15"}</a></Button></div>
  </form>;
}
