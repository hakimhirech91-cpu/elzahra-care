import { Link } from "@tanstack/react-router";
import { CalendarDays, Phone } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/language";

export function PageLayout({ eyebrowAr, eyebrowFr, titleAr, titleFr, textAr, textFr, children, cta = true }: { eyebrowAr: string; eyebrowFr: string; titleAr: string; titleFr: string; textAr: string; textFr: string; children: ReactNode; cta?: boolean }) {
  const { language } = useLanguage(); const ar = language === "ar";
  return <><section className="border-b border-border bg-hero"><div className="section-inner py-16 sm:py-24"><span className="eyebrow">{ar ? eyebrowAr : eyebrowFr}</span><h1 className="max-w-4xl font-display text-4xl leading-tight sm:text-5xl">{ar ? titleAr : titleFr}</h1><p className="mt-5 max-w-2xl text-base leading-8 text-muted-foreground">{ar ? textAr : textFr}</p>{cta && <div className="mt-7 flex flex-wrap gap-3"><Button asChild><Link to="/appointment"><CalendarDays />{ar ? "طلب موعد" : "Demander un rendez-vous"}</Link></Button><Button variant="outline" asChild><a href="tel:+213697978015"><Phone />0697 97 80 15</a></Button></div>}</div></section><section className="section"><div className="section-inner">{children}</div></section></>;
}
