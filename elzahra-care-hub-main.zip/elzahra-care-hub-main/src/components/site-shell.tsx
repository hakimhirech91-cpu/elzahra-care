import { Link, useLocation } from "@tanstack/react-router";
import { CalendarDays, Languages, MapPin, Menu, Phone, ShieldCheck, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/language";

const nav = [
  ["/", "home"], ["/services", "services"], ["/about", "about"], ["/team", "team"],
  ["/patient-info", "patients"], ["/contact", "contact"],
] as const;

export function SiteShell({ children }: { children: ReactNode }) {
  const { language, setLanguage, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const pathname = useLocation({ select: (location) => location.pathname });
  const isAdmin = pathname === "/auth" || pathname === "/admin";
  if (isAdmin) return <>{children}</>;
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="border-b border-border bg-primary px-4 py-2 text-center text-xs font-semibold text-primary-foreground">
        {language === "ar" ? "طلب الموعد لا يُعد تأكيدًا نهائيًا — ستتواصل معكم العيادة." : "La demande de rendez-vous n’est pas une confirmation — la clinique vous contactera."}
      </div>
      <header className="sticky top-0 z-50 border-b border-border/80 bg-background/95 backdrop-blur-xl">
        <div className="mx-auto grid h-20 max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 lg:px-8">
          <Link to="/" className="flex min-w-0 items-center gap-3" aria-label="Centre El-Zahra ORL Djelfa">
            <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground"><span className="text-xl font-bold">Z</span></span>
            <span className="min-w-0"><strong className="block truncate font-display text-base text-primary sm:text-lg">Centre El-Zahra</strong><span className="block truncate text-xs text-muted-foreground">ORL • DJELFA</span></span>
          </Link>
          <nav className="hidden items-center gap-1 xl:flex" aria-label={language === "ar" ? "التنقل الرئيسي" : "Navigation principale"}>
            {nav.map(([to, key]) => <Link key={to} to={to} className="rounded-md px-3 py-2 text-sm font-semibold text-foreground transition hover:bg-secondary hover:text-primary" activeProps={{ className: "bg-secondary text-primary" }}>{t(key)}</Link>)}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden rounded-md border border-border p-1 sm:flex" aria-label="Language">
              <button className={`rounded px-2 py-1 text-xs font-bold ${language === "ar" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`} onClick={() => setLanguage("ar")}>العربية</button>
              <button className={`rounded px-2 py-1 text-xs font-bold ${language === "fr" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`} onClick={() => setLanguage("fr")}>Français</button>
            </div>
            <Button asChild className="hidden md:inline-flex"><Link to="/appointment"><CalendarDays />{t("book")}</Link></Button>
            <Button variant="outline" size="icon" className="xl:hidden" onClick={() => setOpen(!open)} aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}>{open ? <X /> : <Menu />}</Button>
          </div>
        </div>
        {open && <div className="border-t border-border bg-background px-4 py-4 xl:hidden"><nav className="mx-auto grid max-w-7xl gap-1">{nav.map(([to,key]) => <Link key={to} to={to} onClick={() => setOpen(false)} className="rounded-md px-4 py-3 font-semibold hover:bg-secondary">{t(key)}</Link>)}<div className="mt-2 flex gap-2 sm:hidden"><Button variant={language === "ar" ? "default" : "outline"} onClick={() => setLanguage("ar")}><Languages />العربية</Button><Button variant={language === "fr" ? "default" : "outline"} onClick={() => setLanguage("fr")}><Languages />Français</Button></div><Button asChild className="mt-2"><Link to="/appointment" onClick={() => setOpen(false)}><CalendarDays />{t("book")}</Link></Button></nav></div>}
      </header>
      <main>{children}</main>
      <footer className="border-t border-border bg-clinic-dark pb-24 text-clinic-dark-foreground md:pb-0">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-3 lg:px-8">
          <div><div className="mb-4 flex items-center gap-3"><span className="grid size-11 place-items-center rounded-lg bg-primary text-primary-foreground font-bold">Z</span><div><strong className="font-display text-lg">Centre El-Zahra ORL Djelfa</strong><span className="block text-sm text-clinic-dark-muted">عيادة الزهراء</span></div></div><p className="max-w-sm text-sm leading-7 text-clinic-dark-muted">{language === "ar" ? "رعاية متخصصة في طب وجراحة الأنف والأذن والحنجرة في الجلفة." : "Soins spécialisés en oto-rhino-laryngologie à Djelfa."}</p></div>
          <div><h2 className="mb-4 font-display text-base">{language === "ar" ? "روابط سريعة" : "Liens rapides"}</h2><div className="grid grid-cols-2 gap-3 text-sm text-clinic-dark-muted">{nav.map(([to,key]) => <Link key={to} to={to} className="hover:text-clinic-dark-foreground">{t(key)}</Link>)}</div></div>
          <div><h2 className="mb-4 font-display text-base">{t("contact")}</h2><a href="tel:+213697978015" className="mb-3 flex items-center gap-2 text-clinic-dark-muted hover:text-clinic-dark-foreground"><Phone className="size-4" />0697 97 80 15</a><a href="https://www.google.com/maps/search/?api=1&query=M7P4%2BV7%20Djelfa" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-clinic-dark-muted hover:text-clinic-dark-foreground"><MapPin className="size-4" />M7P4+V7 Djelfa</a></div>
        </div>
        <div className="border-t border-clinic-dark-border px-4 py-5"><div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 text-xs text-clinic-dark-muted"><span>© 2026 Centre El-Zahra ORL Djelfa</span><Link to="/auth" className="flex items-center gap-1 hover:text-clinic-dark-foreground"><ShieldCheck className="size-3" />{language === "ar" ? "إدارة العيادة" : "Espace clinique"}</Link></div></div>
      </footer>
      <div className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-3 border-t border-border bg-background p-2 shadow-mobile md:hidden">
        <a href="tel:+213697978015" className="flex flex-col items-center gap-1 py-1 text-xs font-bold text-primary"><Phone className="size-5" />{t("call")}</a>
        <a href="https://www.google.com/maps/search/?api=1&query=M7P4%2BV7%20Djelfa" target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1 py-1 text-xs font-bold text-primary"><MapPin className="size-5" />{t("location")}</a>
        <Link to="/appointment" className="flex flex-col items-center gap-1 rounded-md bg-primary py-1 text-xs font-bold text-primary-foreground"><CalendarDays className="size-5" />{t("book")}</Link>
      </div>
    </div>
  );
}
