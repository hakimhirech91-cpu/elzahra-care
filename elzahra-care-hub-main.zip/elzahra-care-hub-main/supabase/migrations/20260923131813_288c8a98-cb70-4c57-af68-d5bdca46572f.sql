CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE public.clinic_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_name text NOT NULL CHECK (char_length(clinic_name) BETWEEN 1 AND 120),
  clinic_name_ar text NOT NULL CHECK (char_length(clinic_name_ar) BETWEEN 1 AND 120),
  specialty_ar text NOT NULL CHECK (char_length(specialty_ar) BETWEEN 1 AND 180),
  specialty_fr text NOT NULL CHECK (char_length(specialty_fr) BETWEEN 1 AND 180),
  city text NOT NULL CHECK (char_length(city) BETWEEN 1 AND 100),
  address text NOT NULL CHECK (char_length(address) BETWEEN 1 AND 200),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 5 AND 30),
  rating numeric(2,1) CHECK (rating BETWEEN 0 AND 5),
  review_count integer CHECK (review_count >= 0),
  hours_ar text,
  hours_fr text,
  about_ar text,
  about_fr text,
  facebook_url text,
  instagram_url text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.clinic_settings TO anon, authenticated;
GRANT UPDATE ON public.clinic_settings TO authenticated;
GRANT ALL ON public.clinic_settings TO service_role;
ALTER TABLE public.clinic_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Clinic settings are publicly readable" ON public.clinic_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Clinic staff can update settings" ON public.clinic_settings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER clinic_settings_updated_at BEFORE UPDATE ON public.clinic_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_ar text NOT NULL CHECK (char_length(title_ar) BETWEEN 1 AND 120),
  title_fr text NOT NULL CHECK (char_length(title_fr) BETWEEN 1 AND 120),
  description_ar text NOT NULL CHECK (char_length(description_ar) BETWEEN 1 AND 500),
  description_fr text NOT NULL CHECK (char_length(description_fr) BETWEEN 1 AND 500),
  icon text NOT NULL DEFAULT 'stethoscope' CHECK (char_length(icon) BETWEEN 1 AND 40),
  display_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.services TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Active services are publicly readable" ON public.services FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "Clinic staff can read all services" ON public.services FOR SELECT TO authenticated USING (true);
CREATE POLICY "Clinic staff can add services" ON public.services FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Clinic staff can update services" ON public.services FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Clinic staff can delete services" ON public.services FOR DELETE TO authenticated USING (true);
CREATE TRIGGER services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 120),
  role_ar text NOT NULL CHECK (char_length(role_ar) BETWEEN 1 AND 160),
  role_fr text NOT NULL CHECK (char_length(role_fr) BETWEEN 1 AND 160),
  bio_ar text CHECK (bio_ar IS NULL OR char_length(bio_ar) <= 700),
  bio_fr text CHECK (bio_fr IS NULL OR char_length(bio_fr) <= 700),
  image_url text,
  display_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.team_members TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.team_members TO authenticated;
GRANT ALL ON public.team_members TO service_role;
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Active team members are publicly readable" ON public.team_members FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "Clinic staff can read all team members" ON public.team_members FOR SELECT TO authenticated USING (true);
CREATE POLICY "Clinic staff can add team members" ON public.team_members FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Clinic staff can update team members" ON public.team_members FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Clinic staff can delete team members" ON public.team_members FOR DELETE TO authenticated USING (true);
CREATE TRIGGER team_members_updated_at BEFORE UPDATE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.appointment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL CHECK (char_length(full_name) BETWEEN 2 AND 120),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 8 AND 30),
  email text CHECK (email IS NULL OR char_length(email) <= 255),
  consultation_type text NOT NULL CHECK (char_length(consultation_type) BETWEEN 1 AND 120),
  preferred_date date NOT NULL,
  preferred_time text NOT NULL CHECK (char_length(preferred_time) BETWEEN 1 AND 30),
  message text CHECK (message IS NULL OR char_length(message) <= 1000),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'scheduled', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.appointment_requests TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.appointment_requests TO authenticated;
GRANT ALL ON public.appointment_requests TO service_role;
ALTER TABLE public.appointment_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors can request appointments" ON public.appointment_requests FOR INSERT TO anon WITH CHECK (status = 'new');
CREATE POLICY "Clinic staff can read appointment requests" ON public.appointment_requests FOR SELECT TO authenticated USING (true);
CREATE POLICY "Clinic staff can update appointment requests" ON public.appointment_requests FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Clinic staff can delete appointment requests" ON public.appointment_requests FOR DELETE TO authenticated USING (true);
CREATE TRIGGER appointment_requests_updated_at BEFORE UPDATE ON public.appointment_requests FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.clinic_settings (clinic_name, clinic_name_ar, specialty_ar, specialty_fr, city, address, phone, rating, review_count, hours_ar, hours_fr, about_ar, about_fr)
VALUES (
  'Centre El-Zahra ORL Djelfa',
  'عيادة الزهراء',
  'طب وجراحة الأنف والأذن والحنجرة',
  'Médecine et chirurgie ORL',
  'Djelfa, Algeria',
  'M7P4+V7 Djelfa',
  '0697 97 80 15',
  4.3,
  9,
  NULL,
  NULL,
  'رعاية متخصصة في طب وجراحة الأنف والأذن والحنجرة في مدينة الجلفة، مع اهتمام براحة المريض ووضوح المعلومات وسهولة التواصل.',
  'Des soins spécialisés en oto-rhino-laryngologie à Djelfa, avec une attention particulière au confort du patient, à la clarté des informations et à la facilité de contact.'
);

INSERT INTO public.services (title_ar, title_fr, description_ar, description_fr, icon, display_order) VALUES
('أمراض الأنف والجيوب الأنفية', 'Affections du nez et des sinus', 'تشخيص ومتابعة مختلف مشاكل الأنف والجيوب الأنفية.', 'Diagnostic et suivi des différents troubles du nez et des sinus.', 'nose', 1),
('أمراض الأذن والسمع', 'Affections de l’oreille et de l’audition', 'فحص ومتابعة مشاكل الأذن والسمع والتوازن.', 'Examen et suivi des troubles de l’oreille, de l’audition et de l’équilibre.', 'ear', 2),
('أمراض الحنجرة والصوت', 'Affections du larynx et de la voix', 'تقييم ومتابعة اضطرابات الحنجرة والصوت.', 'Évaluation et suivi des troubles du larynx et de la voix.', 'audio', 3),
('فحوصات ORL', 'Examens ORL', 'فحوصات وتشخيصات متخصصة في مجال الأنف والأذن والحنجرة.', 'Examens et diagnostics spécialisés en oto-rhino-laryngologie.', 'stethoscope', 4),
('طب الأطفال ORL', 'ORL pédiatrique', 'متابعة مشاكل الأنف والأذن والحنجرة لدى الأطفال.', 'Suivi des troubles ORL chez l’enfant.', 'child', 5);